# Sakura Nocturne für kitty und Neovim

Die Farben entsprechen dem Sakura-Nocturne-Theme für Rider: dunkelgrauer Hintergrund (`#17171B`), Hauptschrift `#EDA3B1`, Akzente in Pink, Magenta und Rot.

## kitty

`kitty/sakura-nocturne.conf` nach `~/.config/kitty/sakura-nocturne.conf` kopieren und in `~/.config/kitty/kitty.conf` die Zeile `include sakura-nocturne.conf` ergänzen. Die Font- und Tastatureinstellungen bleiben dabei erhalten.

## Neovim / LazyVim

Den Inhalt des Ordners `nvim` nach `~/.config/nvim` kopieren. `colors/sakura-nocturne.lua` enthält das Farbschema; die Dateien in `lua/plugins` aktivieren es in LazyVim und wählen das passende Lualine-Theme. `lua/lualine/themes/sakura-nocturne.lua` liefert dessen Farben.

Die Highlight-Gruppen decken unter anderem Neo-tree, Bufferline, Lualine, Gitsigns, Which-key, Noice, Blink, Snacks, FzfLua, Flash, Trouble, Todo Comments und Render Markdown ab. Mini Icons verknüpft seine Icon-Farben mit den Farben des Farbschemas.
