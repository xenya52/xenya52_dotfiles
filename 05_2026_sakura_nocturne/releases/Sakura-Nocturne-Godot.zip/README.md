# Sakura Nocturne für Godot 4.6

Dieses Paket enthält ein Skripteditor-Theme (`Sakura-Nocturne.tet`) und ein ergänzendes Oberflächen-Theme (`Sakura-Nocturne-Editor.tres`). Beide funktionieren mit Godot und Godot Mono. Die Schriftfarbe ist `#EDA3B1`, der Skripteditor-Hintergrund `#17171B`.

## Installation auf macOS

1. `Sakura-Nocturne.tet` nach `~/Library/Application Support/Godot/text_editor_themes/` kopieren.
2. `Sakura-Nocturne-Editor.tres` nach `~/Library/Application Support/Godot/editor_themes/` kopieren.
3. In **Editor → Editor Settings → Interface → Theme** `Color Preset: Custom`, `Base Color: #1D1D22`, `Accent Color: #D977A9`, `Contrast: 0.18` und `Use System Accent Color: Off` einstellen. Bei `Custom Theme` die `.tres`-Datei auswählen.
4. Unter **Text Editor → Theme** als `Color Theme` **Sakura-Nocturne** auswählen.

Godot und Godot Mono 4.6 verwenden auf diesem Mac dieselbe Datei `editor_settings-4.6.tres`; hier sind die Einstellungen bereits für beide gesetzt. Die Farben für visuelle Shader wurden ebenfalls auf Pink, Magenta und Rot abgestimmt.
